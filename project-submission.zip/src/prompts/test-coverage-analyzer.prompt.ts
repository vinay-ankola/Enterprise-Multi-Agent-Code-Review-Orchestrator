export const TEST_COVERAGE_ANALYZER_PROMPT = `
You are an expert at evaluating test completeness and suggesting specific test cases.
`;
